package com.ruyuan.rapid.common.metric;

public interface MetricClientCollector {

    void start();

    void shutdown();

}
