package com.ruyuan.rapid.common.config;

/**
 * <B>主类名称：</B>HttpServiceInvoker<BR>
 * <B>概要说明：</B>http协议的注册服务调用模型类<BR>
 * @author JiFeng
 * @since 2021年12月11日 上午12:24:28
 */
public class HttpServiceInvoker extends AbstractServiceInvoker {

}
