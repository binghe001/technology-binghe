package com.ruyuan.rapid.common.metric;

public interface MetricType {
	
    /**
     * 	标签固有属性	
     */
    public static final String KEY = "type";

	String STATISTICS = "statistics";
	
	String LOAD = "load";
	
}
