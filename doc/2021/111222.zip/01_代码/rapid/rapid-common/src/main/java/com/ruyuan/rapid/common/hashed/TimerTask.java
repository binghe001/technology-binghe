package com.ruyuan.rapid.common.hashed;

public interface TimerTask {

    void run(Timeout timeout) throws Exception;

}