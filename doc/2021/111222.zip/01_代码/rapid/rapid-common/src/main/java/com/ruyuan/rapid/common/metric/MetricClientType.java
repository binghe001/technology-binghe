package com.ruyuan.rapid.common.metric;

public enum MetricClientType {

    FILE, KAFKA, NETTY 

}
