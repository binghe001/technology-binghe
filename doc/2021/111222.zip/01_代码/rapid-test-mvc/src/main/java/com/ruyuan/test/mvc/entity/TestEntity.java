package com.ruyuan.test.mvc.entity;

import lombok.Data;

@Data
public class TestEntity {
    private String name;
    private Integer age;
}
